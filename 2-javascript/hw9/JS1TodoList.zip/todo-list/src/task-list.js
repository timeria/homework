import Task from './task.js'

export default class TaskList {
  constructor(){
    this.tasks = []
  }

  addTask(description){
    const task = new Task(description)
    this.tasks.push(task)
  }

  renderTasks(){
    const taskListElement = document.getElementById('task-list')
    taskListElement.textContent = ''

    this.tasks.forEach((task) => {
      const listItem = document.createElement('li')
      listItem.innerHTML = `
        <input type="checkbox" ${task.completed ? 'checked' : ''}>
        <span>${task.description}</span>
      `

      listItem.querySelector('input').addEventListener('change', () => {
        task.toggle()
        this.renderTasks()
      })
      taskListElement.appendChild(listItem)
    })
  }
}